global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6283143851170']
global.gambar = ""
// GANTI NO OWNER DENGAN NOMOR MU LALU RUNN SEPERTI BIASA !!!